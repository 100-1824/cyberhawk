<?php
require_once 'routes/routes.php';
?>